# 📸 Como Editar as Imagens do Site

Este guia explica como substituir as imagens dos serviços no site Auto Limpeza Pro.

## 📁 Localização das Imagens

As imagens estão organizadas em duas pastas principais:

### 1. Imagens de Estoque (Stock Images)
**Pasta:** `attached_assets/stock_images/`

Estas são as imagens dos serviços que podem ser substituídas:

| Arquivo | Serviço | Tamanho Recomendado |
|---------|---------|---------------------|
| `professional_car_int_509c7a17.jpg` | Higienização Estofados Auto | 1200x800px |
| `professional_mattres_a5521721.jpg` | Higienização de Colchões | 1200x800px |
| `professional_sofa_co_4f9057b1.jpg` | Higienização de Sofás | 1200x800px |
| `professional_carpet__923a0a1c.jpg` | Higienização Carpetes | 1200x800px |
| `office_chair_upholst_cfcbc227.jpg` | Higienização Cadeiras | 1200x800px |
| `curtain_drapes_clean_7ded74bb.jpg` | Higienização Cortinas | 1200x800px |
| `car_polishing_buffin_9d3953a3.jpg` | Polimento Técnico | 1200x800px |
| `car_ceramic_coating__0223fb37.jpg` | Cristalização/Vitrificação | 1200x800px |
| `car_headlight_restor_5424a7cc.jpg` | Revitalização Faróis | 1200x800px |
| `luxury_car_leather_s_4853d257.jpg` | Hidratação de Couro | 1200x800px |
| `car_wash_cleaning_ex_9329e98c.jpg` | Lavagem Express | 1200x800px |

### 2. Imagens Principais
**Pasta:** `src/assets/`

| Arquivo | Uso | Tamanho Recomendado |
|---------|-----|---------------------|
| `hero-upholstery-cleaning.jpg` | Imagem principal do Hero | 1920x1080px |
| `estofado-destaque.jpg` | Seção destaque página inicial | 1200x800px |
| `exterior-wash.jpg` | Lavagem completa | 1200x800px |
| `interior-detail.jpg` | Detalhamento interno | 1200x800px |
| `wax-polish.jpg` | Polimento e enceramento | 1200x800px |

---

## 🔧 Como Substituir uma Imagem

### Método 1: Substituir Arquivo Direto (Mais Fácil)

1. **Prepare sua imagem:**
   - Formato: JPG ou PNG
   - Tamanho recomendado: 1200x800px (proporção 3:2)
   - Peso: máximo 500KB para performance

2. **Renomeie sua imagem:**
   - Use EXATAMENTE o mesmo nome do arquivo que quer substituir
   - Exemplo: Se quer trocar a imagem de colchões, renomeie para `professional_mattres_a5521721.jpg`

3. **Substitua o arquivo:**
   - Vá até a pasta `attached_assets/stock_images/`
   - Delete o arquivo antigo
   - Cole seu novo arquivo com o mesmo nome

4. **Teste:**
   - Rode `npm run dev`
   - Acesse o site e verifique se a imagem foi atualizada

### Método 2: Usar Novo Nome de Arquivo (Mais Flexível)

1. **Adicione sua imagem:**
   - Coloque a nova imagem em `attached_assets/stock_images/`
   - Use um nome descritivo, ex: `minha_higienizacao_sofa.jpg`

2. **Edite o código:**
   - Abra o arquivo `src/pages/Services.tsx`
   - Localize a importação da imagem que quer trocar (linhas 13-24)
   - Altere o caminho do import

**Exemplo:**

Trocar a imagem de sofás:

```typescript
// ANTES:
import sofaCleaning from "@assets/stock_images/professional_sofa_co_4f9057b1.jpg";

// DEPOIS:
import sofaCleaning from "@assets/stock_images/minha_higienizacao_sofa.jpg";
```

3. **Salve e teste:**
   - Salve o arquivo
   - O site atualizará automaticamente

---

## 📝 Editando Descrições dos Serviços

Para alterar o texto/descrição de um serviço:

1. Abra `src/pages/Services.tsx`
2. Localize o array `allServices` (linha 26)
3. Encontre o serviço pelo `id` ou `name`
4. Edite os campos:
   - `name`: Nome do serviço
   - `description`: Descrição detalhada
   - `price`: Preço em reais (decimal com ponto)
   - `duration`: Tempo estimado

**Exemplo:**

```typescript
{
  id: "hig-1",
  name: "Higienização de Estofados Automotivos",
  description: "Sua descrição aqui...",
  price: 200.00,  // Altere o preço aqui
  duration: "2-3h",
  rating: 4.9,
  image: carInteriorClean,
  category: "higienizacao",
  isPopular: true,
}
```

---

## 🎨 Dicas de Qualidade de Imagem

### Características Ideais:
- ✅ Alta resolução (mínimo 1200px de largura)
- ✅ Bem iluminada
- ✅ Focada no serviço
- ✅ Profissional
- ✅ Formato horizontal (paisagem)
- ✅ Peso otimizado (< 500KB)

### O que Evitar:
- ❌ Imagens borradas ou de baixa qualidade
- ❌ Marca d'água de outros sites
- ❌ Fotos muito escuras
- ❌ Proporções verticais (retrato)
- ❌ Arquivos muito grandes (> 2MB)

### Otimização de Imagens:

Use ferramentas online gratuitas para otimizar:
- [TinyPNG](https://tinypng.com/) - Compressão sem perda de qualidade
- [Squoosh](https://squoosh.app/) - Editor e otimizador do Google
- [CompressJPEG](https://compressjpeg.com/) - Compressão rápida

---

## 🏷️ Tabela de Mapeamento Completo

| ID Serviço | Nome do Serviço | Variável de Importação | Arquivo da Imagem |
|------------|-----------------|------------------------|-------------------|
| hig-1 | Higienização Estofados Auto | `carInteriorClean` | professional_car_int_509c7a17.jpg |
| hig-2 | Higienização de Colchões | `mattressCleaning` | professional_mattres_a5521721.jpg |
| hig-3 | Higienização de Sofás | `sofaCleaning` | professional_sofa_co_4f9057b1.jpg |
| hig-4 | Higienização Cadeiras | `chairCleaning` | office_chair_upholst_cfcbc227.jpg |
| hig-5 | Higienização Carpetes | `carpetCleaning` | professional_carpet__923a0a1c.jpg |
| hig-6 | Higienização Cortinas | `curtainCleaning` | curtain_drapes_clean_7ded74bb.jpg |
| est-1 | Polimento Técnico | `carPolishing` | car_polishing_buffin_9d3953a3.jpg |
| est-2 | Cristalização | `ceramicCoating` | car_ceramic_coating__0223fb37.jpg |
| est-3 | Vitrificação Premium | `ceramicCoating` | car_ceramic_coating__0223fb37.jpg |
| est-4 | Revitalização Faróis | `headlightRestoration` | car_headlight_restor_5424a7cc.jpg |
| est-5 | Hidratação de Couro | `leatherTreatment` | luxury_car_leather_s_4853d257.jpg |
| est-6 | Ozonização | `interiorDetail` | interior-detail.jpg (pasta assets) |
| lav-1 | Lavagem Express | `carWashExpress` | car_wash_cleaning_ex_9329e98c.jpg |
| lav-2 | Lavagem Completa | `exteriorWash` | exterior-wash.jpg (pasta assets) |

---

## ⚙️ Após Editar as Imagens

### Desenvolvimento (Teste Local):
```bash
npm run dev
```
Acesse: http://localhost:5000

### Produção (Deploy):
```bash
# Executar build
npm run build

# OU usar o script para cPanel
./build-cpanel.sh
```

---

## 🆘 Problemas Comuns

### Imagem não aparece:
1. Verifique o nome do arquivo (case-sensitive)
2. Confirme que a extensão está correta (.jpg, .png)
3. Limpe o cache do navegador (Ctrl+Shift+R)
4. Verifique o caminho do import no código

### Imagem muito grande/lenta:
1. Otimize a imagem com TinyPNG
2. Reduza a resolução para 1200x800px
3. Converta PNG para JPG se possível

### Erro ao fazer build:
1. Verifique se o arquivo da imagem existe
2. Confira se não há erros de sintaxe no Services.tsx
3. Rode `npm install` novamente

---

## 📞 Suporte

Se precisar de ajuda, entre em contato com o desenvolvedor responsável.

**Última atualização:** Outubro 2025
