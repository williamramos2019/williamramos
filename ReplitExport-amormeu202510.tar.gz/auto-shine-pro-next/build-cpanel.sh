#!/bin/bash

# Script de Build para cPanel - Auto Limpeza Pro
# Este script prepara a aplicação para upload no cPanel

echo "========================================="
echo "  Build para cPanel - Auto Limpeza Pro  "
echo "========================================="
echo ""

# Verificar se o npm está instalado
if ! command -v npm &> /dev/null; then
    echo "❌ Erro: npm não está instalado"
    exit 1
fi

echo "✓ npm encontrado"
echo ""

# Instalar dependências
echo "📦 Instalando dependências..."
npm install --legacy-peer-deps

if [ $? -ne 0 ]; then
    echo "❌ Erro ao instalar dependências"
    exit 1
fi

echo "✓ Dependências instaladas"
echo ""

# Executar build de produção
echo "🔨 Executando build de produção..."
npm run build

if [ $? -ne 0 ]; then
    echo "❌ Erro durante o build"
    exit 1
fi

echo "✓ Build concluído com sucesso"
echo ""

# Criar arquivo .htaccess para React Router
echo "📝 Criando arquivo .htaccess..."
cat > dist/.htaccess << 'EOF'
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteCond %{REQUEST_FILENAME} !-l
  RewriteRule . /index.html [L]
</IfModule>

# Habilitar compressão GZIP
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript application/x-javascript application/json
</IfModule>

# Configurar cache do navegador
<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresByType image/jpg "access plus 1 year"
  ExpiresByType image/jpeg "access plus 1 year"
  ExpiresByType image/gif "access plus 1 year"
  ExpiresByType image/png "access plus 1 year"
  ExpiresByType image/svg+xml "access plus 1 year"
  ExpiresByType text/css "access plus 1 month"
  ExpiresByType application/javascript "access plus 1 month"
  ExpiresByType application/pdf "access plus 1 month"
  ExpiresByType text/x-javascript "access plus 1 month"
</IfModule>
EOF

echo "✓ Arquivo .htaccess criado"
echo ""

# Criar arquivo robots.txt se não existir
if [ ! -f dist/robots.txt ]; then
    echo "📝 Criando robots.txt..."
    cat > dist/robots.txt << 'EOF'
User-agent: *
Allow: /
Sitemap: https://seudominio.com/sitemap.xml
EOF
    echo "✓ robots.txt criado"
    echo ""
fi

# Instruções finais
echo "========================================="
echo "  ✅ BUILD CONCLUÍDO COM SUCESSO!"
echo "========================================="
echo ""
echo "📁 Arquivos de produção estão em: ./dist"
echo ""
echo "📤 INSTRUÇÕES PARA UPLOAD NO CPANEL:"
echo ""
echo "1. Acesse o cPanel do seu servidor"
echo "2. Vá em 'Gerenciador de Arquivos'"
echo "3. Navegue até a pasta public_html"
echo "4. Faça upload de TODOS os arquivos da pasta 'dist'"
echo "5. Certifique-se de que o arquivo .htaccess foi enviado"
echo "   (às vezes arquivos ocultos não são mostrados)"
echo ""
echo "⚙️  CONFIGURAÇÕES ADICIONAIS:"
echo ""
echo "- Se usar subdomínio: coloque os arquivos em public_html/subdominio"
echo "- Atualize a URL no arquivo robots.txt"
echo "- Verifique se o mod_rewrite está ativado no Apache"
echo ""
echo "🔗 Acesse: https://seudominio.com"
echo ""
echo "========================================="
