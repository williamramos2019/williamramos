# Auto Limpeza Pro - Replit Configuration

## Visão Geral
Aplicação React + Vite importada do GitHub para higienização de estofados automotivos, colchões e sofás em São José da Lapa - MG.

## Estrutura do Projeto
- **Frontend**: React 18 + TypeScript + Vite
- **UI**: shadcn/ui + Tailwind CSS + Radix UI
- **Roteamento**: wouter
- **Backend**: Supabase (integração configurada)
- **Formulários**: react-hook-form + zod
- **Consultas**: @tanstack/react-query

## Configuração Replit

### Porta e Host
- Frontend rodando na porta **5000** (obrigatório no Replit)
- Host configurado para `0.0.0.0` 
- `allowedHosts: true` habilitado para aceitar o proxy do Replit (formato booleano obrigatório no Vite 5.4.19)

### Workflow
- Nome: **Start application**
- Comando: `npm run dev`
- Porta: 5000
- Tipo: webview

### Instalação de Dependências
As dependências devem ser instaladas com:
```bash
npm install --legacy-peer-deps
```
Isso é necessário devido a um conflito de versão entre `react-day-picker@8.10.1` e `date-fns@4.1.0`.

## Deploy
- Tipo: autoscale
- Build: `npm run build`
- Run: `npm run preview`

## Arquivos Modificados
- `vite.config.ts`: Configurado para Replit (porta 5000, allowedHosts, HMR clientPort 443)

## Build para Produção (cPanel)

### Script de Build Automatizado
Um script shell foi criado para facilitar o build e preparação para cPanel:

```bash
./build-cpanel.sh
```

Este script:
1. Instala as dependências necessárias
2. Executa o build de produção
3. Cria arquivo .htaccess com configurações de roteamento
4. Otimiza cache e compressão
5. Fornece instruções detalhadas de upload

### Build Manual
```bash
npm install --legacy-peer-deps
npm run build
```

Os arquivos de produção estarão em: `./dist`

### Upload no cPanel
1. Acesse o Gerenciador de Arquivos no cPanel
2. Navegue até `public_html`
3. Faça upload de TODOS os arquivos da pasta `dist`
4. Certifique-se que o `.htaccess` foi enviado

## Gerenciamento de Imagens

### Como Editar Imagens dos Serviços
Consulte o arquivo `COMO_EDITAR_IMAGENS.md` para instruções detalhadas sobre:
- Localização de todas as imagens
- Como substituir imagens dos serviços
- Tamanhos e formatos recomendados
- Otimização de imagens
- Edição de descrições dos serviços

### Localizações Principais
- Imagens de serviços: `attached_assets/stock_images/`
- Imagens principais: `src/assets/`
- Configuração dos serviços: `src/pages/Services.tsx`

## Observações
- Erro de WebSocket no console é esperado no ambiente Replit (limitação do proxy)
- A aplicação funciona perfeitamente apesar da mensagem de erro do WebSocket
- Hot reload pode não funcionar perfeitamente, mas recarregar a página manualmente funciona
