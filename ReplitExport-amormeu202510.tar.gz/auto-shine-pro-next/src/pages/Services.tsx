import { useState } from "react";
import { ServiceCard } from "@/components/ServiceCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { Search, Filter, Car, Sparkles } from "lucide-react";

// Importar imagens originais
import exteriorWash from "@/assets/exterior-wash.jpg";
import interiorDetail from "@/assets/interior-detail.jpg";
import waxPolish from "@/assets/wax-polish.jpg";

// Importar novas imagens de stock
import carInteriorClean from "@assets/stock_images/professional_car_int_509c7a17.jpg";
import mattressCleaning from "@assets/stock_images/professional_mattres_a5521721.jpg";
import sofaCleaning from "@assets/stock_images/professional_sofa_co_4f9057b1.jpg";
import carpetCleaning from "@assets/stock_images/professional_carpet__923a0a1c.jpg";
import chairCleaning from "@assets/stock_images/office_chair_upholst_cfcbc227.jpg";
import curtainCleaning from "@assets/stock_images/curtain_drapes_clean_7ded74bb.jpg";
import carPolishing from "@assets/stock_images/car_polishing_buffin_9d3953a3.jpg";
import ceramicCoating from "@assets/stock_images/car_ceramic_coating__0223fb37.jpg";
import headlightRestoration from "@assets/stock_images/car_headlight_restor_5424a7cc.jpg";
import leatherTreatment from "@assets/stock_images/luxury_car_leather_s_4853d257.jpg";
import carWashExpress from "@assets/stock_images/car_wash_cleaning_ex_9329e98c.jpg";

const allServices = [
  // Higienização - 6 serviços principais
  {
    id: "hig-1",
    name: "Higienização de Estofados Automotivos",
    description: "Limpeza profunda e completa de bancos, tapetes, forração de teto e porta-malas. Utilizamos equipamentos de extração a quente e produtos especializados que eliminam sujeira profunda, manchas difíceis, odores desagradáveis e ácaros. Processo com secagem rápida e proteção impermeabilizante opcional.",
    price: 200.00,
    duration: "2-3h",
    rating: 4.9,
    image: carInteriorClean,
    category: "higienizacao",
    isPopular: true,
  },
  {
    id: "hig-2",
    name: "Higienização de Colchões",
    description: "Higienização profissional de colchões com sistema de extração a seco e vapor. Elimina ácaros, fungos, bactérias e odores. Ideal para quem sofre com alergias. Processo completo inclui aspiração profunda, aplicação de produtos hipoalergênicos, extração de sujeira e eliminação de 99,9% dos ácaros. Secagem rápida de 2 a 4 horas.",
    price: 120.00,
    duration: "1-2h",
    rating: 4.8,
    image: mattressCleaning,
    category: "higienizacao",
  },
  {
    id: "hig-3",
    name: "Higienização de Sofás",
    description: "Limpeza profissional de sofás de 2 ou 3 lugares com tecnologia de extração. Remove manchas, sujeira acumulada e odores desagradáveis. Processo seguro para todos os tipos de tecido (suede, linho, veludo, jacquard). Inclui aspiração profunda, pré-tratamento de manchas, limpeza com produtos específicos e proteção opcional contra novas manchas.",
    price: 140.00,
    duration: "1h 30min",
    rating: 4.8,
    image: sofaCleaning,
    category: "higienizacao",
  },
  {
    id: "hig-4",
    name: "Higienização de Cadeiras e Poltronas",
    description: "Limpeza especializada de cadeiras de escritório, poltronas decorativas e cadeiras estofadas. Ideal para ambientes corporativos e residenciais. Remove manchas, sujeira e odores, prolongando a vida útil do móvel. Processo rápido com secagem em até 2 horas. Produtos específicos para cada tipo de tecido e revestimento.",
    price: 60.00,
    duration: "40min",
    rating: 4.7,
    image: chairCleaning,
    category: "higienizacao",
  },
  {
    id: "hig-5",
    name: "Higienização de Carpetes e Tapetes",
    description: "Limpeza profissional de carpetes e tapetes residenciais e comerciais (preço por m²). Utilizamos sistema de extração profunda que remove sujeira, ácaros e manchas sem danificar as fibras. Ideal para recuperar carpetes antigos e manter a aparência de novos. Secagem rápida e resultado duradouro. Mínimo de 10m².",
    price: 20.00,
    duration: "Variável",
    rating: 4.7,
    image: carpetCleaning,
    category: "higienizacao",
  },
  {
    id: "hig-6",
    name: "Higienização de Cortinas",
    description: "Limpeza especializada de cortinas pesadas, persianas de tecido e cortinas decorativas (preço por m²). Processo cuidadoso que preserva cores e tecidos delicados. Remove poeira acumulada, manchas e odores. Ideal para quem tem alergias. Pode ser feita no local (sem remover as cortinas) ou com remoção para limpeza mais profunda. Mínimo de 5m².",
    price: 28.00,
    duration: "Variável",
    rating: 4.6,
    image: curtainCleaning,
    category: "higienizacao",
  },

  // Estética Automotiva - 6 serviços
  {
    id: "est-1",
    name: "Polimento Técnico",
    description: "Polimento profissional em 3 etapas para remoção de riscos leves, marcas de lavagem, oxidação e manchas na pintura. Devolve o brilho original do veículo. Utilizamos politrizes roto-orbital e produtos de alta performance. Processo inclui: descontaminação da pintura, polimento de correção, refino e aplicação de cera de proteção. Resultado com brilho intenso e profundo.",
    price: 320.00,
    duration: "3-4h",
    rating: 4.9,
    image: carPolishing,
    category: "estetica",
    isPopular: true,
  },
  {
    id: "est-2",
    name: "Cristalização de Pintura",
    description: "Proteção avançada com selante cerâmico de alta durabilidade (6 a 12 meses). Cria uma camada protetora contra raios UV, chuva ácida, poluição e sujeira. Proporciona brilho espelhado e facilita a limpeza futura do veículo. O processo inclui: polimento leve, aplicação do selante cerâmico em duas camadas e cura. Efeito hidrofóbico (repele água).",
    price: 450.00,
    duration: "4-5h",
    rating: 5.0,
    image: ceramicCoating,
    category: "estetica",
  },
  {
    id: "est-3",
    name: "Vitrificação Premium",
    description: "Proteção máxima com revestimento cerâmico de altíssima durabilidade (2 a 5 anos). A vitrificação cria uma camada permanente super resistente a riscos, produtos químicos, raios UV e oxidação. Brilho incomparável e efeito autolimpante. Processo completo: polimento técnico de correção, descontaminação química, aplicação do vitrificador em 3 camadas e cura de 24h. Garantia de 2 anos.",
    price: 1200.00,
    duration: "6-8h",
    rating: 5.0,
    image: ceramicCoating,
    category: "estetica",
  },
  {
    id: "est-4",
    name: "Revitalização de Faróis",
    description: "Polimento e restauração completa de faróis opacos, amarelados ou foscos. Remove oxidação e arranhões, devolvendo transparência original. Melhora significativamente a iluminação noturna e segurança. Processo profissional: lixamento em várias etapas, polimento, aplicação de proteção UV permanente. Resultado: faróis com aparência de novos e proteção contra nova oxidação por até 2 anos.",
    price: 200.00,
    duration: "1-2h",
    rating: 4.8,
    image: headlightRestoration,
    category: "estetica",
  },
  {
    id: "est-5",
    name: "Hidratação de Couro",
    description: "Tratamento completo e profissional de bancos de couro automotivo. Processo em 4 etapas: limpeza profunda com produtos específicos, nutrição com condicionadores premium, hidratação intensiva e proteção UV. Devolve maciez, flexibilidade e aspecto de novo ao couro. Previne ressecamento, rachaduras e desbotamento. Recomendado a cada 6 meses.",
    price: 280.00,
    duration: "2h",
    rating: 4.8,
    image: leatherTreatment,
    category: "estetica",
  },
  {
    id: "est-6",
    name: "Ozonização",
    description: "Higienização e desinfecção completa do sistema de ar-condicionado e interior do veículo usando ozônio (O3). Elimina 99,9% de bactérias, vírus, fungos e ácaros. Remove odores persistentes (mofo, cigarro, animais, vômito). Purifica o ar e sanitiza superfícies. Processo ecológico e seguro. Deixa um aroma neutro e agradável. Recomendado especialmente após enchentes ou para veículos com mau cheiro.",
    price: 100.00,
    duration: "1h",
    rating: 4.7,
    image: interiorDetail,
    category: "estetica",
  },

  // Lavagem Express
  {
    id: "lav-1",
    name: "Lavagem Express",
    description: "Lavagem externa rápida e eficiente para o dia a dia. Inclui: lavagem com espuma ativa, enxágue sob pressão, secagem com ar comprimido e pano de microfibra. Ideal para manutenção semanal do veículo. Limpa carroceria, vidros, rodas e pneus. Serviço rápido sem comprometer a qualidade.",
    price: 35.00,
    duration: "30min",
    rating: 4.6,
    image: carWashExpress,
    category: "express",
  },
  {
    id: "lav-2",
    name: "Lavagem Completa",
    description: "Lavagem externa completa com aspiração interna do veículo. Parte externa: lavagem detalhada da carroceria, limpeza de rodas e pneus, vidros, pretejamento de pneus. Parte interna: aspiração de bancos, tapetes, porta-malas e console, limpeza de painel e portas, vidros internos. Serviço completo para deixar seu veículo limpo por dentro e por fora.",
    price: 80.00,
    duration: "1h",
    rating: 4.8,
    image: exteriorWash,
    category: "completa",
  },
];

const categories = [
  { id: "all", label: "Todos", icon: Car },
  { id: "higienizacao", label: "Higienização", icon: Sparkles },
  { id: "estetica", label: "Estética Auto", icon: Sparkles },
  { id: "express", label: "Express", icon: Car },
  { id: "completa", label: "Completa", icon: Car },
];

export default function Services() {
  const [, setLocation] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  const filteredServices = allServices.filter((service) => {
    const matchesCategory = selectedCategory === "all" || service.category === selectedCategory;
    const matchesSearch = service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         service.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleBookService = (serviceId: string) => {
    setLocation(`/booking?service=${serviceId}`);
  };

  return (
    <div className="min-h-screen py-8 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            Nossos Serviços
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Escolha entre nossa ampla gama de serviços profissionais de higienização e estética automotiva
          </p>
        </div>

        {/* Search and Filters */}
        <div className="space-y-6 mb-8">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar serviços..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              data-testid="input-search-services"
            />
          </div>

          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((category) => {
              const Icon = category.icon;
              return (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "premium" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category.id)}
                  className="gap-2"
                  data-testid={`button-filter-${category.id}`}
                >
                  <Icon className="h-4 w-4" />
                  {category.label}
                </Button>
              );
            })}
          </div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredServices.map((service) => (
            <ServiceCard
              key={service.id}
              {...service}
              onBookService={handleBookService}
            />
          ))}
        </div>

        {filteredServices.length === 0 && (
          <div className="text-center py-12">
            <Car className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Nenhum serviço encontrado</h3>
            <p className="text-muted-foreground">
              Tente ajustar os filtros ou termo de busca
            </p>
          </div>
        )}

        {/* CTA Section */}
        <div className="mt-16 text-center bg-muted/20 rounded-xl p-8">
          <h2 className="text-2xl font-bold mb-4">
            Não encontrou o que procurava?
          </h2>
          <p className="text-muted-foreground mb-6">
            Entre em contato conosco para serviços personalizados
          </p>
          <Button variant="premium" size="lg" data-testid="button-contact-specialist">
            Falar com Especialista
          </Button>
        </div>
      </div>
    </div>
  );
}
